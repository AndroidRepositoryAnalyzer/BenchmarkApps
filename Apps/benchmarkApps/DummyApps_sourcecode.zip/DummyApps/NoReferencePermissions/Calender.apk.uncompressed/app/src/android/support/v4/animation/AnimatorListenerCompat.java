package android.support.v4.animation;

public interface AnimatorListenerCompat
{
    void onAnimationCancel(ValueAnimatorCompat p0);
    
    void onAnimationEnd(ValueAnimatorCompat p0);
    
    void onAnimationRepeat(ValueAnimatorCompat p0);
    
    void onAnimationStart(ValueAnimatorCompat p0);
}
