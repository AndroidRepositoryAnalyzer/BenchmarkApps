package android.support.design.widget;

import android.graphics.drawable.*;

interface ShadowViewDelegate
{
    float getRadius();
    
    boolean isCompatPaddingEnabled();
    
    void setBackgroundDrawable(Drawable p0);
    
    void setShadowPadding(int p0, int p1, int p2, int p3);
}
