package android.support.v4.app;

import android.content.*;
import android.app.*;
import android.os.*;

public class NotificationCompatBase
{
    public static Notification add(final Notification notification, final Context context, final CharSequence charSequence, final CharSequence charSequence2, final PendingIntent pendingIntent) {
        notification.setLatestEventInfo(context, charSequence, charSequence2, pendingIntent);
        return notification;
    }
    
    public abstract static class Action
    {
        public abstract PendingIntent getActionIntent();
        
        public abstract Bundle getExtras();
        
        public abstract int getIcon();
        
        public abstract RemoteInputCompatBase.RemoteInput[] getRemoteInputs();
        
        public abstract CharSequence getTitle();
        
        public interface Factory
        {
            Action build(int p0, CharSequence p1, PendingIntent p2, Bundle p3, RemoteInputCompatBase.RemoteInput[] p4);
            
            Action[] newArray(int p0);
        }
    }
    
    public abstract static class UnreadConversation
    {
        abstract long getLatestTimestamp();
        
        abstract String[] getMessages();
        
        abstract String getParticipant();
        
        abstract String[] getParticipants();
        
        abstract PendingIntent getReadPendingIntent();
        
        abstract RemoteInputCompatBase.RemoteInput getRemoteInput();
        
        abstract PendingIntent getReplyPendingIntent();
        
        public interface Factory
        {
            UnreadConversation build(String[] p0, RemoteInputCompatBase.RemoteInput p1, PendingIntent p2, PendingIntent p3, String[] p4, long p5);
        }
    }
}
