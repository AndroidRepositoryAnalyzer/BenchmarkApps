package android.support.v4.app;

interface NotificationBuilderWithActions
{
    void addAction(NotificationCompatBase.Action p0);
}
