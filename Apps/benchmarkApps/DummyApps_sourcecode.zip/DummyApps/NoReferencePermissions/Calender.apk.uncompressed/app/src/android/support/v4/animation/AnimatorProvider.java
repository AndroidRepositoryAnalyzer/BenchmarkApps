package android.support.v4.animation;

import android.view.*;

interface AnimatorProvider
{
    void clearInterpolator(View p0);
    
    ValueAnimatorCompat emptyValueAnimator();
}
