package android.support.v4.animation;

import android.view.*;

public interface ValueAnimatorCompat
{
    void addListener(AnimatorListenerCompat p0);
    
    void addUpdateListener(AnimatorUpdateListenerCompat p0);
    
    void cancel();
    
    float getAnimatedFraction();
    
    void setDuration(long p0);
    
    void setTarget(View p0);
    
    void start();
}
