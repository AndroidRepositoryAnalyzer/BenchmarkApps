package android.support.design.widget;

import android.view.*;
import android.support.v4.view.*;

interface CoordinatorLayoutInsetsHelper
{
    void setupForWindowInsets(View p0, OnApplyWindowInsetsListener p1);
}
