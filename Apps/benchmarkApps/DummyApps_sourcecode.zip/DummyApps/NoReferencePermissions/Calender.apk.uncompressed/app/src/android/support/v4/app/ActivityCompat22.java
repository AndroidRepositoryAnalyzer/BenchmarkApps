package android.support.v4.app;

import android.app.*;
import android.net.*;

class ActivityCompat22
{
    public static Uri getReferrer(final Activity activity) {
        return activity.getReferrer();
    }
}
