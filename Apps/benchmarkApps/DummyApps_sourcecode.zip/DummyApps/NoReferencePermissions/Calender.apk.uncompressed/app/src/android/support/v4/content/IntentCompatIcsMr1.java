package android.support.v4.content;

import android.content.*;

class IntentCompatIcsMr1
{
    public static Intent makeMainSelectorActivity(final String s, final String s2) {
        return Intent.makeMainSelectorActivity(s, s2);
    }
}
