package android.support.v4.accessibilityservice;

import android.accessibilityservice.*;

class AccessibilityServiceInfoCompatJellyBeanMr2
{
    public static int getCapabilities(final AccessibilityServiceInfo accessibilityServiceInfo) {
        return accessibilityServiceInfo.getCapabilities();
    }
}
