package android.support.v4.graphics;

import android.graphics.*;

class BitmapCompatHoneycombMr1
{
    static int getAllocationByteCount(final Bitmap bitmap) {
        return bitmap.getByteCount();
    }
}
